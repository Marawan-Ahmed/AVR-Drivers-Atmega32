/*********************************************************/
/***********		Author: TaqiEldeen	 	**************/
/***********		Layer: 				 	**************/
/***********		Component: 				**************/
/***********		Version: 1.00		 	**************/
/***********		Date: 26 Aug 2023		 	**************/
/*********************************************************/

#include "../LIB/BIT_Math.h"
#include "../LIB/STD_Types.h"

#include <avr/io.h>
#include <avr/interrupt.h>

#include "../MCAL/DIO/DIO.h"
#include "../MCAL/INT/INT.h"
#include "../MCAL/TIMER0/TIM0.h"

#include "../HAL/LCD/LCD.h"

volatile u16 Global_u16Tperiod = 0;
volatile u16 Global_u16Tfalling = 0;
volatile u8 Global_u8Flag = 0;

int main() {
	/* EXTI0 Pin*/
	DIO_voidSetPinDirection(DIO_PORTD, DIO_PIN2, DIO_INPUT);
	DIO_voidSetPinValue(DIO_PORTD, DIO_PIN2, DIO_HIGH);

	/* OC0 Pin */
	DIO_voidSetPinDirection(DIO_PORTB, DIO_PIN3, DIO_OUTPUT);

	/* TIM0
	 * 1- prescaler 8
	 * 2- Fast PWM
	 * 3- Non-inverting
	 * 4- Tperiod = 256uS
	 * */
	TIM0_voidInit();
	TIM0_voidPWMGenerator(30, TIM0_OC0_CLR_CMP_SET_OVF);

	/* TIM1
	 * 1- Normal mode
	 * 2- prescaler 8
	 * */
	TCCR1A = 0x00;
	TCCR1B = 0x00;

	/*
	 * INT0
	 * 1- Rising edge
	 * **/
	INT_voidEnable(INT_INT0, INT_RISING_EDGE);

	/*
	 * LCD
	 * */
	LCD_voidInit();

	/* Start PWM */
	TIM0_voidTimerStart(TIM0_PRESCALER_8);

	/* Enable global interrupt*/
	sei();


	u8 Local_u8DutyCycle = 0;
	u16 Local_u16Ton = 0, Local_u16Freq = 0;

	while(1){
		if(Global_u8Flag == 1) {
			Local_u16Ton = Global_u16Tfalling - Global_u16Tperiod;
			Local_u8DutyCycle = (100 * Local_u16Ton) / Global_u16Tperiod;
			Local_u16Freq = 1000000UL / Global_u16Tperiod;

			LCD_voidSendString("D: ");
			LCD_voidSendNumber(Local_u8DutyCycle);
			LCD_voidSendChar('%');

			LCD_voidSetLocation(LCD_LINE2, 0);
			LCD_voidSendString("F: ");
			LCD_voidSendNumber(Local_u16Freq);
			LCD_voidSendString("HZ");

			Global_u8Flag = 0;
		}
	}
}

ISR(INT0_vect) {
	static u8 Local_u8Counter = 0;
	Local_u8Counter++;

	if(Local_u8Counter == 1) {		/* First Rising Edge */
		SET_BIT(TCCR1B,CS11);		/* Start Timer1 for counting */
	} else if(Local_u8Counter == 2) {
		Global_u16Tperiod = TCNT1;	/* Take snapshot */
		INT_voidEnable(INT_INT0, INT_FALLING_EDGE);
	} else if(Local_u8Counter == 3) {
		Global_u16Tfalling = TCNT1;	/* Take snapshot */
		CLR_BIT(TCCR1B,CS11);		/* Stop Timer1 */
		TIM0_voidTimerStop();		/* Stop PWM */
		INT_voidDisable(INT_INT0);
		Global_u8Flag = 1;
	}
}
