/*
 * main.c
 *
 *  Created on: Aug 14, 2023
 *      Author: Salem Elfaidy
 */
#include <avr/io.h>
#include <util/delay.h>
#include "LIB/BIT_Math.h"
#include "LIB/STD_Types.h"
#include "MCAL/DIO/DIO.h"
#include "HAL/KEYPAD/KEYPAD.h"
#include "HAL/LCD/LCD.h"
#include "MCAL/INT/INT.h"
#include <avr/interrupt.h>
#include "MCAL/ADC/ADC.h"
#include "MCAL/TIMER0/TIM0.h"
#include "MCAL/WDT/WDT.h"
#include "MCAL/ICU/ICU.h"

void ICU_HW (void);
volatile u16 PeriodTicks =0, ONTicks =0;


int main(){

	LCD_voidInit();
	TIM0_voidInit();
	ICU_voidInit();

	DIO_voidSetPinDirection(DIO_PORTB, DIO_PIN3, DIO_OUTPUT);
	DIO_voidSetPinDirection(DIO_PORTD, DIO_PIN6, DIO_INPUT);

	TIM0_voidPWMGenerator(20, TIM0_OC0_CLR_UPC_SET_DNC);
	TIM0_voidTimerStart(TIM0_PRESCALER_8);

	sei();
	ICU_voidSetCallback(&ICU_HW);


	while(1){

		while((PeriodTicks ==0) || (ONTicks ==0)){
			LCD_voidSendString("CycleTicks:");
			LCD_voidSendNumber(PeriodTicks);

			LCD_voidSetLocation(LCD_LINE2, 0);
			LCD_voidSendString("OnTicks:");
			LCD_voidSendNumber(ONTicks);
		}
	}


	return 0;
}




void ICU_HW (void){
	static u8 Local_u8Count =0;
	static u16 Local_u16Read_1, Local_u16Read_2, Local_u16Read_3;

	if (Local_u8Count == 1) {
		Local_u16Read_1 = ICU_u16ReadValue();

	} else if(Local_u8Count == 2){
		Local_u16Read_2 = ICU_u16ReadValue();
		ICU_voidChangeTrigger(ICU_FALLING_EDGE);
		PeriodTicks = Local_u16Read_2 - Local_u16Read_1;
	}
	else if(Local_u8Count == 3){
		Local_u16Read_3 = ICU_u16ReadValue();
		ONTicks = Local_u16Read_3 - Local_u16Read_2;
		ICU_voidDisableInterrupt();
	}

	Local_u8Count++;
}





